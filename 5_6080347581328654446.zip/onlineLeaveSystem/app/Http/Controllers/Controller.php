<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class Controller extends BaseController
{
    public function homePage(){
        return view('homePage');
    }


    public function addNewUser(){

        return view('addUser');
//        dd($request->all());
    }

//    public function staffLogin(){
//        dd('staffLogin');
//    }
//
//    public function supervisorLogin(){
//        dd('supervisorLogin');
//    }

    public function updateNewUser(Request $request){

        if ($request->isMethod('post')){

//            dd($request->all(),$request->_token);
            unset($request['token']);

            $userDetails=[
                'name' => $request->name,
                'emailId' => $request->email,
                'password' => Hash::make($request->password),
                'empType' => $request->empType == 'supervisor' ? 'S' : $request->empType,
            ];
//            dd($userDetails);
            $res = DB::table('users')->insert($userDetails);
            if ($res){
                return redirect()->back()->with('successMsg','Successfully Inserted....');
            }else{
                return redirect()->back()->with('errMsg','Something went wrong...! Please Try Again');

            }
        }

    }

}
