<html>
<title>Staff Dashboard</title>
<h2>Staff Dashboard</h2>
<body style="text-align: center">
{{--{{dd($UserData)}}--}}
<form method="get" action="/applyLeave">
    <p >Employee Id :<span id="empId">{{$UserData['id']}}</span></p>
    <p>Name : {{$UserData['name']}}</p>
    <p>email Id : {{$UserData['emailId']}}</p>
    <button >Apply For Leave</button>
</form>
<form method="get" action="/checkLeaveStatus">
    <button> Check Leave Status</button>
</form>

<script>
    function applyForLeave() {
        var res = document.getElementById("empId").textContent;
        empId = res.trim();
        alert(empId)
        $.ajax({
            url:'/applyLeave',
            method:'get',
            data:{
                empId:empId
            }
        })

    }
</script>
</body>
</html>