<?php

namespace App\Modules\Staff\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class StaffController
{

    public function staffLogin(Request $request)
    {
        unset($request['_token']);
        $UserEmailId = $request['emailId'];
        $UserPassword = $request['password'];



        if (Auth::attempt(['emailId'=> $UserEmailId, 'password'=>$UserPassword])){
            $staffDeails = Auth::user();
            Session::put('staffDetails',$staffDeails);
            return redirect('/staffDashboard');

        }else{
            dd('else');
        }

        $res = DB::table('employee')->where(['emailId'=> $UserEmailId, 'password'=>$UserPassword])->get();
        $res = $res->toArray();
//        $details[0] = json_decode(json_encode($res,true),true);

        if(!empty($res)){

            $empType = $res[0]->empType;
//            dd($empType);

            if ($empType == 'staff'){

                Session::put('staffDetails',$res);
               return redirect('/staffDashboard');

            }elseif($empType == 'supervisor'){
                dd('elseif');
            }else{
                dd('else');
            }

        }else{

            return redirect()->back()->with('errMsg','invalid credential...!');
        }

//        dd($UserEmailId,$UserPassword,$request['emailId']);

//        if (Auth::attempt(['emailId'=> $UserEmailId, 'password'=>$UserPassword])){
//            dd('if');
//
//        }
    }



    public function staffDashboard()
    {
        $UserData = Session::get('staffDetails');
        return view('Staff::staffDashboard',['UserData'=>$UserData]);
    }


    public function applyLeave(Request $request)
    {
//        dd($request->all());
        if($request->isMethod('post')){
            unset($request['token']);
            $userLeave=[
                'empId' => $request->empId,
                'sender' => $request->from,
                'receive' => $request->to,
                'leaveType' => $request->leaveType,
                'subject' => $request->subject,
                'body' => $request->body,
                'status' => 'P',
            ];
            $res = DB::table('applied_Leaves')->insert($userLeave);
            if ($res){
                return redirect()->back()->with('successMsg','Successfully applied Leaves....');
            }else{
                return redirect()->back()->with('errMsg','Something went wrong...! Please Try Again');

            }
        }else{
            $UserData = Session::get('staffDetails');
//            dd('Here');
            return view('Staff::applyLeave',['UserData'=>$UserData]);
        }


    }




    public function checkLeaveStatus()
    {
        $UserData = Session::get('staffDetails');
        $emailId = $UserData['emailId'];
        $res = DB::table('applied_leaves')->where(['sender'=>$emailId])->get();
        $UserData = json_decode(json_encode($res), true);
        return view('Staff::applyTable',['data'=>$UserData]);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
