<?php

Route::group(['module' => 'Staff', 'middleware' => ['web'], 'namespace' => 'App\Modules\Staff\Controllers'], function() {

    Route::resource('staff', 'StaffController');

    Route::post('/staffLogin','StaffController@staffLogin');
    Route::get('/staffDashboard','StaffController@staffDashboard');


    Route::get('/applyLeave','StaffController@applyLeave');
    Route::post('/applyLeave','StaffController@applyLeave');


    Route::get('/checkLeaveStatus','StaffController@checkLeaveStatus');

});
