<?php

Route::group(['module' => 'Staff', 'middleware' => ['api'], 'namespace' => 'App\Modules\Staff\Controllers'], function() {

    Route::resource('staff', 'StaffController');

});
