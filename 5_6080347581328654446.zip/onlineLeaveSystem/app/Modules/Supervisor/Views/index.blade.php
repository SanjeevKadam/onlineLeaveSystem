<?php

echo trans('Supervisor::example.welcome');