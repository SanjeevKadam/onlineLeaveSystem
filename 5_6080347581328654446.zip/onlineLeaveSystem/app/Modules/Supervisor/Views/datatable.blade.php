<!DOCTYPE html>
<html>
<head>
    <title>Demo</title>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    {{--For DataTable--}}

    <link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

    {{--SweetAlert2--}}

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css"/>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>

    <style>
        .table th {
            background-color: #67BCDB;
        }

        /*.table tr:hover {background-color:#00FFFF;}*/
        /*.btn:hover {*/
        /*background-color: #00FFFF;*/
        /*color:#fff;*/
        /*}*/
        .btn:hover {
            background-color: #FF0000;
            color: #fff;
        }
        .modal-align {
            margin-top: 5%;
        }
    </style>

</head>
<body>
{{--Display Sweet alert--}}
@if(session('sweetAlertMsg'))
    @include('sweet::alert');
@endif

@if(session('msg'))
    <div class="alert alert-info">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        {{session('msg')}}
    </div>
@endif
<center><h3><u>Demo</u></h3></center>

<div class="container">
    <table id="datatable" class="table table-bordered">
        <thead>
        <tr>
            <th>id</th>
            <th>Name</th>
            {{--<th>sender</th>--}}
            {{--<th>Stream Required</th>--}}
            {{--<th>Man Required</th>--}}
            {{--<th>Action</th>--}}
            {{--<th>Criteria</th>--}}
        </tr>
        </thead>
    </table>
</div>

<script type="text/javascript">
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(document).ready(function () {
        $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: '/datatable/demo',
            columns: [
                {data: 'id', name: 'id'},
                {data: 'name', name: 'name'}
                // {data: 'dateofcoming', name: 'dateofcoming'},
                // {data: 'streamrequired', name: 'streamrequired'},
                // {data: 'manrequired', name: 'manrequired'},
                // {data: 'action', name: 'action'},
                // {data: 'criteria', name: 'criteria'}
            ]
        });
        $(document.body).on('click', '.moreDetails', function () {

//            alert( $(this).attr('data-id'));
//            return false;

            $.ajax({

                'url': '/student-criterialist',
                'type': 'post',
                'dataType': 'json',
                'data': {companyId: $(this).attr('data-id')},
                'beforeSend': function () {

                    $('#loadModal').modal('show');
                    $('#myModal').modal('hide');
                    $('#laoder').show();

                },

                'success': function (response) {

                    setTimeout(function () {
                        $('#laoder').hide();
                        $('#loadModal').modal('hide');
                        $('#myModal').modal('show');
                    }, 5000);


//                    console.log(response); //Displaying Data in Console

                    if (response['status'] == 200) {

                        var tbodyHtml = '';
                        $.each(response.data, function (i, o) {
                            console.log(i, '-----------------', o);
                            tbodyHtml = '<tr> ' +
                                '<td>' + o.tenpercentagerequired + '</td> ' +
                                '<td>' + o.twelvepercentagerequired + '</td > ' +
                                '<td>' + o.bepercentagerequired + '</td> ' +
                                '<td>' + o.skillrequired + ' </td> ' +
                                '<td>' + o.jobtitles + '</td> ' +
                                '</tr>';
                        });
                        $('#tbody').html(tbodyHtml);

//                        $('#myModal').modal('show');
                    } else {
                        alert(response.message);
                    }
                }
            });
        });
    });
</script>

<!-- Showing Loding Modal -->
<div class="modal fade modal-align" id="loadModal" role="dialog" data-backdrop="static">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div id="laoder">
                <center><img src="/images/spinner.gif" alt=""></center>
                <center><h3><i><font color="Lime ">Please Wait.Page is Loading.....</font> </i></h3></center>
            </div>
        </div>
    </div>
</div>

<!-- Modal to show extra details -->
<div class="modal fade" id="myModal" role="dialog" data-backdrop="static">

    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">
                    <center>Student Criteria</center>
                </h4>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th><strong>10% Required</strong></th>
                        <th><strong>12% Required</strong></th>
                        <th><strong>BE% Required</strong></th>
                        <th><strong>Skill Required</strong></th>
                        <th><strong>Job Titles</strong></th>
                    </tr>
                    </thead>
                    <tbody id="tbody">

                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<div style="width:4%;height: 32px;margin-left:8%;margin-top:0%;background-color: #5bc0de;border-radius: 10%;">
    <a href="/dashboard" class="btn btn-default">Back</a>
</div>
</body>
</html>

