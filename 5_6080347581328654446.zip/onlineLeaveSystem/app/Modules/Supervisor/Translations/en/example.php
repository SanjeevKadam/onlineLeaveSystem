<?php 

return [
    'welcome' => 'Welcome, this is Supervisor module.'
];
