<?php

Route::group(['module' => 'Supervisor', 'middleware' => ['api'], 'namespace' => 'App\Modules\Supervisor\Controllers'], function() {

    Route::resource('supervisor', 'SupervisorController');

});
