<?php

Route::group(['module' => 'Supervisor', 'middleware' => ['web'], 'namespace' => 'App\Modules\Supervisor\Controllers'], function() {

    Route::resource('supervisor', 'SupervisorController');


    Route::post('/supervisorLogin','SupervisorController@supervisorLogin');

    Route::get('/supervisorDashboard','SupervisorController@supervisorDashboard');

    Route::get('/datatable/getdata', 'SupervisorController@getPosts');


//    Route::post('/changeStatu','SupervisorController@changeStatus');


    Route::post('/demo','SupervisorController@demo');
//    Route::post('/demo1','SupervisorController@demo1');
//    Route::post('/demo',function (){dd('hesdgsdg@@re');});






    Route::get('/table','SupervisorController@table');


    Route::get('/datatable', 'SupervisorController@datatable');
// Get Data

    // Display view
//    Route::get('/datatable', 'DataTableController@datatable');
    // Get Data
//    Route::get('datatable/getdata', 'DataTableController@getPosts')->name('datatable/getdata');

    Route::get('/datatable/demo', 'DataTableController@getPosts');

});
