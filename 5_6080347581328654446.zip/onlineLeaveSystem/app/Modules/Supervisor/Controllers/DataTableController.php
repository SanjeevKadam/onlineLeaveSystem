<?php
/**
 * Created by PhpStorm.
 * User: GLB-211
 * Date: 12/7/2018
 * Time: 8:58 PM
 */

namespace App\Modules\Supervisor\Controllers;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Redirect;
use DataTables;

class DataTableController extends Controller
{
    public function datatable()
    {
        return view('datatable');
    }

    public function getPosts(Request $request)
    {
        $data = DB::table('applied_leaves')->get();
        $dt = json_decode(json_encode($data), true);
        $userData = new Collection();
        foreach ($dt as $item){
            $userData->push([
                'id' => $item['id'],
                'name' => $item['empId'],
                'sender' => $item['sender'],
                'subject' => $item['subject'],
                'body' => $item['body'],
                'status' => $item['status'],

            ]);

        }
//        dd($userData);
        return \Yajra\DataTables\Facades\DataTables::of($userData)->make(true);
    }
}