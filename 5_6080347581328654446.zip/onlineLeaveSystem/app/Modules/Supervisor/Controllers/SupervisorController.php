<?php

namespace App\Modules\Supervisor\Controllers;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\Contracts\DataTable;
use Yajra\DataTables\Facades\DataTables;

class SupervisorController
{

    public function supervisorLogin(Request $request)
    {
//        dd($request->all());

        unset($request['_token']);
        $UserEmailId = $request['emailId'];
        $UserPassword = $request['password'];

        if (Auth::attempt(['emailId'=>$UserEmailId,'password'=>$UserPassword])){
            $supervisorDeails = Auth::user();
//            dd($supervisorDeails['name']);
            Session::put('supervisorDetails',$supervisorDeails);
            Session::put('supervisorDetails',$supervisorDeails);
           return redirect('/supervisorDashboard');
        }else{

        }

    }


    public function supervisorDashboard()
    {
       $supervisorDetails = Session::get('supervisorDetails');
//       dd($supervisorDetails);

       return view('Supervisor::supervisorDetails',['UserData'=>$supervisorDetails]);
//       return view('Supervisor::table');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function datatable(Request $request)
    {
        dd('sjg');
        return view('Supervisor::supervisorDetails');
    }

    public function getPosts(Request $request)
    {
        $data = DB::table('applied_leaves')->get();
        $dt = json_decode(json_encode($data), true);
//        dd($dt);
        return view('Supervisor::table',['data'=>$dt]);



//        return \DataTables::of($data)->make(true);
        $userData = new Collection();
        foreach ($dt as $item){
//            dd($item);
            $userData->push([
                'id' => $item['id'],
                'name' => $item['empId'],
                'sender' => $item['sender'],
                'subject' => $item['subject'],
                'body' => $item['body'],
                'status' => $item['status'],

            ]);

        }
//        dd($userData);
        return DataTables::of($userData)->make(true);
//        return DataTable::of($userData)->make(true);
//        return DataTables::of($userData)->rawColumns(['id', 'name','sender','subject','body','status'])->make(true);
//        return \DataTables::of($data)->make(true);
    }



    public function demo(Request $request){
//        dd($request->all());
        $id = $request['leaveId'];
        $str = $request['status'];
        $status = str_replace($id,"",$str);

        $data = DB::table('applied_leaves')->where('id',$id)->first();
        $res1 = json_decode(json_encode($data,true),true);

        if ($status == "approve"){
            $res =DB::table('applied_leaves')->where('id',$id)->update(['status'=>'A']);
            if ($res){
                echo json_encode(['status'=>200,'msg' => 'status has been Update']);
            }else{
                echo json_encode(['status'=>400,'msg' => 'Error','data'=>$res1]);
            }
        }else{
            $res =DB::table('applied_leaves')->where('id',$id)->update(['status'=>'R']);
            if ($res){
                echo json_encode(['status'=>500,'msg' => 'status has been Update']);
            }else{
                echo json_encode(['status'=>400,'msg' => 'Error','data'=>$res1]);
            }
        }

//        dd($res);

//        if ($res){
//            echo json_encode(['status'=>200,'msg' => 'status has been Update']);
//        }else{
//            echo json_encode(['status'=>400,'msg' => 'Error','data'=>$res1]);
//        }
    }


//    public function demo1(Request $request){
//        $id = $request['leaveId'];
//        $res = DB::table('applied_leaves')->where('id',$id)->update(['status'=>'P']);
//
//        $data = DB::table('applied_leaves')->where('id',$id)->first();
//        $res1 = json_decode(json_encode($data,true),true);
//        if ($res){
//            return json_encode(['status'=>200,'msg' => 'status has been Rejected','data'=>$res1]);
//        }else{
//            return json_encode(['status'=>400,'msg' => 'Error']);
//        }
//    }

}
