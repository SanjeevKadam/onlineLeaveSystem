<?php

namespace App\Modules\Supervisor\Models;

use Illuminate\Database\Eloquent\Model;

class Supervisor extends Model {

    //

}
