<html>
<title>Add New User</title>
<body>


<div style="text-align: center">

    @if(Session::has('successMsg'))
        <div class="alert alert-success" style="color: green"> {{ session('successMsg') }}</div>
    @endif

    @if(Session::has('errMsg'))
        <div class="alert alert-danger" style="color: red"> {{ session('errMsg') }}</div>
    @endif




    <form method="post" action="/addNewUser">
        {{csrf_field()}}
        <p>Name : <input type="text" name="name" placeholder="Enter User Name" required> </p>
        <p>Email Id : <input type="email" name="email" placeholder="Enter email Id" required></p>
        <p>Password : <input type="text" name="password" placeholder="Enter Password" required></p>

        <p>Employee Type :

            <select name="empType" required>
                <option selected></option>
                <option value="staff">Staff</option>
                <option value="supervisor">Supervisor</option>
            </select>
        </p>
        <button value="Create">Create Employee</button>
    </form>
   <a href="/"> <button>Home Page</button></a>
</div>
</body>
</html>