<?php
/**
 * Created by PhpStorm.
 * User: GLB-211
 * Date: 12/8/2018
 * Time: 12:42 PM
 */
?>

<html>
<head>
    <title>Demo</title>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .th{
            text-align: center;
        }

    </style>
</head>
<body>
<div class="container" style="margin-top: 5%;">
    <table class="table table-bordered" width="80%">
        <thead style="background-color: aquamarine;">
        <tr>
            <th class="th">id</th>
            <th class="th">sender</th>
            <th>subject</th>
            <th>body</th>
            <th>status</th>
        </tr>
        </thead>
        <tbody>
        <?php for($i=0;$i<count($data);$i++): ?>
            <tr>
                <td ><?php echo e($data[$i]['id']); ?></td>
                <input type="hidden" id="leaveId" value="<?php echo e($data[$i]['id']); ?>">
                <td><?php echo e($data[$i]['sender']); ?></td>
                <td><?php echo e($data[$i]['subject']); ?></td>
                <td><?php echo e($data[$i]['body']); ?></td>
                <?php if($data[$i]['status'] == 'A'): ?>
                    <td ><button style="background-color: #70ea64" >Approve</button></td>
                <?php elseif($data[$i]['status'] == 'R'): ?>
                    <td><button style="background-color: #f75461"    >Reject</button></td>
                <?php else: ?>
                    <td ><button >Pending</button></td>
                <?php endif; ?>
            </tr>
        <?php endfor; ?>
        </tbody>
    </table>
</div>
<br>
<a href="/staffDashboard" style="margin-left:700px " ><button >Back to Dashboard</button></a>
</body>
</html>
