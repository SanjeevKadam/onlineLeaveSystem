<html>
<title>Apply Leave</title>
<body style="text-align: center">
<h2>Appling For Leave</h2>
<?php if(Session::has('successMsg')): ?>
    <div class="alert alert-success" style="color: green"> <?php echo e(session('successMsg')); ?></div>
<?php endif; ?>

<?php if(Session::has('errMsg')): ?>
    <div class="alert alert-danger" style="color: red"> <?php echo e(session('errMsg')); ?></div>
<?php endif; ?>

<form method="post" action="/applyLeave">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="empId" value="<?php echo e($UserData['id']); ?>">
    <p>From : <input type="text" name="from" value="<?php echo e($UserData['emailId']); ?>"></p>
    <p>To : <input type="email" name="to" ></p>
    <p>Leave Type :

        <select name="leaveType" style="width: 10%" required>
            <option selected></option>
            <option value="annual">Annual</option>
            <option value="medical">Medical</option>
            <option value="casval">Casval</option>
        </select>
    </p>
    <p>Subject : <input type="text" name="subject" ></p>
    Body : <p><textarea rows="4" cols="50" name="body"></textarea></p>
    <button type="submit">Send</button>
</form>
<a href="/staffDashboard"><button >Back to Dashboard</button></a>
</body>
</html>