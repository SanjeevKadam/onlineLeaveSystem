<html>
<head>
    <title>Demo</title>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .th{
            text-align: center;
        }

    </style>
</head>
<bod>
    <div class="container" style="margin-top: 5%;">
        <table class="table table-bordered" width="80%">
           <thead style="background-color: aquamarine;">
           <tr>
               <th class="th">id</th>
               <th class="th">sender</th>
               <th>subject</th>
               <th>body</th>
               <th>status</th>
           </tr>
           </thead>
            <tbody>
            <?php for($i=0;$i<count($data);$i++): ?>
                <tr>
                <td ><?php echo e($data[$i]['id']); ?></td>
                <input type="hidden" id="leaveId" value="<?php echo e($data[$i]['id']); ?>">
                <td><?php echo e($data[$i]['sender']); ?></td>
                <td><?php echo e($data[$i]['subject']); ?></td>
                <td><?php echo e($data[$i]['body']); ?></td>
                
                <?php if($data[$i]['status'] == 'A'): ?>
                    <td id="<?php echo e($data[$i]['id']); ?>"><button style="background-color: #70ea64" id="approve<?php echo e($data[$i]['id']); ?>" onclick="changeStatus('approve<?php echo e($data[$i]['id']); ?>','<?php echo e($data[$i]['id']); ?>')">Approve</button>
                        <button id="reject<?php echo e($data[$i]['id']); ?>" onclick="changeStatus('reject<?php echo e($data[$i]['id']); ?>','<?php echo e($data[$i]['id']); ?>')">Reject</button></td>
                <?php elseif($data[$i]['status'] == 'R'): ?>
                    <td  id="<?php echo e($data[$i]['id']); ?>"><button id="approve<?php echo e($data[$i]['id']); ?>" onclick="changeStatus('approve<?php echo e($data[$i]['id']); ?>','<?php echo e($data[$i]['id']); ?>')">Approve</button>
                        <button style="background-color: #f75461"   id="reject<?php echo e($data[$i]['id']); ?>" onclick="changeStatus('reject<?php echo e($data[$i]['id']); ?>','<?php echo e($data[$i]['id']); ?>')">Reject</button></td>
                <?php else: ?>
                <td id="<?php echo e($data[$i]['id']); ?>"><button  id="approve<?php echo e($data[$i]['id']); ?>" onclick="changeStatus('approve<?php echo e($data[$i]['id']); ?>','<?php echo e($data[$i]['id']); ?>')">Approve</button>
                    <button id="reject<?php echo e($data[$i]['id']); ?>" onclick="changeStatus('reject<?php echo e($data[$i]['id']); ?>','<?php echo e($data[$i]['id']); ?>')">Reject</button></td>

                <?php endif; ?>

            </tr>
            <?php endfor; ?>
            </tbody>
        </table>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });




        function changeStatus(status,id) {
            var leaveId = id;
            var status=status;
           $.ajax({
               url:'/demo',
               method:'post',
               data:{leaveId:id,status:status},


               success: function (response) {
                   response =  $.parseJSON(response)
                   console.log(response['status']);
                   if (response['status'] == 200) {

                       $('#' + status).css("color", "none");

                       $('#' + status).attr("style", "background:#70ea64");

                       // var rawhtml="<td id='approve"+id+"'>" +
                       // "<button id='approve"+id+"' onclick='changeStatus('approve"+id+"','"+id+"')'>Approve</button>"
                       //     "<button id='reject"+id+"' onclick='changeStatus('reject"+id+"','"+id+"')'>Reject</button></td>";

                   }

                   if (response['status'] == 500){
                       var res = $('#' + status).css('background','none');
                       if(res){

                           $('#' + status).attr("style", "background:#f75461");
                       }

                   }
               }

           })

        }

        // function changeStatus1(status,id) {
        //
        //     var leaveId = id;
        //     var status=status;
        //     alert(status);
        //     $.ajax({
        //         url:'/demo1',
        //         method:'post',
        //         data:{leaveId:id},
        //
        //
        //         success: function (response) {
        //             if (response['status'] == 200) {
        //                 console.log(response.data);
        //                 // $('#' + status).css("backgroud-color", "green");
        //                 $('#' + status).style.color("backgroud-color", "green");
        //                 var rawhtml="<td id='approve"+id+"'>" +
        //                     "<button id='approve"+id+"' onclick='changeStatus('approve"+id+"','"+id+"')'>Approve</button>"
        //                 "<button id='reject"+id+"' onclick='changeStatus('reject"+id+"','"+id+"')'>Reject</button></td>";
        //
        //             }else{
        //                 // $('#' + status).css("color", "red");
        //                 $('#' + status).style.color("backgroud-color", "red");
        //             }
        //         }
        //
        //     })
        //
        // }

    </script>
</bod>
</html>