<html>
<title>Home</title>
<body style="text-align: center;margin-top: 8%;">


    <?php if(Session::has('successMsg')): ?>
        <div class="alert alert-success" style="color: green"> <?php echo e(session('successMsg')); ?></div>
    <?php endif; ?>

    <?php if(Session::has('errMsg')): ?>
        <div class="alert alert-danger" style="color: red"> <?php echo e(session('errMsg')); ?></div>
    <?php endif; ?>
<div style="display: inline-block";width="50%;">
    <h3>Staff Login</h3>
    <form method="post" action="/staffLogin">
        <?php echo e(csrf_field()); ?>

        <p>Email Id : <input type="email" name="emailId" placeholder="Please Enter Your EmailId"></p>
        <p>Password : <input type="password" name="password" placeholder="Please Enter Your Password"></p>
        <button type="submit">Login</button>
    </form>
</div>



<div style="float: right;width: 50%;">

    <h3>Supervisor Login</h3>
    <form method="post" action="/supervisorLogin">

        <p>Email Id : <input type="text" name="emailId" placeholder="Please Enter Your EmailId"></p>
        <p>Password : <input type="password" name="password" placeholder="Please Enter Your Password"></p>
        <?php echo e(csrf_field()); ?>

        <button>Login</button>
    </form>
</div>



<div>
    <form method="get" action="/addNewUser">
        
        <button type="submit">Add New User</button>
    </form>
</div>


</body>
</html>