<html>
<title>Add New User</title>
<body>


<div style="text-align: center">

    <?php if(Session::has('successMsg')): ?>
        <div class="alert alert-success" style="color: green"> <?php echo e(session('successMsg')); ?></div>
    <?php endif; ?>

    <?php if(Session::has('errMsg')): ?>
        <div class="alert alert-danger" style="color: red"> <?php echo e(session('errMsg')); ?></div>
    <?php endif; ?>




    <form method="post" action="/addNewUser">
        <?php echo e(csrf_field()); ?>

        <p>Name : <input type="text" name="name" placeholder="Enter User Name" required> </p>
        <p>Email Id : <input type="email" name="email" placeholder="Enter email Id" required></p>
        <p>Password : <input type="text" name="password" placeholder="Enter Password" required></p>

        <p>Employee Type :

            <select name="empType" required>
                <option selected></option>
                <option value="staff">Staff</option>
                <option value="supervisor">Supervisor</option>
            </select>
        </p>
        <button value="Create">Create Employee</button>
    </form>
   <a href="/"> <button>Home Page</button></a>
</div>
</body>
</html>