<?php
/**
 * Created by PhpStorm.
 * User: GLB-211
 * Date: 12/7/2018
 * Time: 6:42 PM
 */
?>
<html>
<title>Supervisor Dashboard</title>
<h2>Supervisor Dashboard</h2>
<body style="text-align: center">

<form method="get" action="/datatable/getdata">
    <p >Employee Id :<span id="empId"><?php echo e($UserData['id']); ?></span></p>
    <p>Name : <?php echo e($UserData['name']); ?></p>
    <p>email Id : <?php echo e($UserData['emailId']); ?></p>
    <button >Check Leave Table</button>
</form>

<script>
    function applyForLeave() {
        var res = document.getElementById("empId").textContent;
        empId = res.trim();
        alert(empId)
        $.ajax({
            url:'/applyLeave',
            method:'get',
            data:{
                empId:empId
            }
        })

    }
</script>
</body>
</html>
