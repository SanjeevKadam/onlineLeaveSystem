<html>
<title>Staff Dashboard</title>
<h2>Staff Dashboard</h2>
<body style="text-align: center">

<form method="get" action="/applyLeave">
    <p >Employee Id :<span id="empId"><?php echo e($UserData['id']); ?></span></p>
    <p>Name : <?php echo e($UserData['name']); ?></p>
    <p>email Id : <?php echo e($UserData['emailId']); ?></p>
    <button >Apply For Leave</button>
</form>
<form method="get" action="/checkLeaveStatus">
    <button> Check Leave Status</button>
</form>

<script>
    function applyForLeave() {
        var res = document.getElementById("empId").textContent;
        empId = res.trim();
        alert(empId)
        $.ajax({
            url:'/applyLeave',
            method:'get',
            data:{
                empId:empId
            }
        })

    }
</script>
</body>
</html>